Update users based on the CSV file

You can update users based on the CSV file if the automatic options to fix invalid 
and duplicated email addresses in the migration assistant are too generic for you. After you 
upload the CSV file, we'll use it during your next migration.

You can view this and other documentation pages at:
https://support.atlassian.com/migration/docs/update-users-based-on-the-csv-file/

** About the CSV file **
A separate CSV file is generated for users with invalid and duplicated email addresses, 
so you need to handle each of these cases separately.

* Good to know *
You can modify existing users in the file, but you can’t add or delete users. If the number 
of users in the uploaded CSV file is different than in the original file, you won’t be able 
to upload it.

** Example CSV file **
Here's sample data for users with invalid email addresses:

|    UserKey    | UserName | Type |    OldEmail     |         NewEmail         | Tombstone |
--------------------------------------------------------------------------------------------
| JIRAUSER10105 | user1    | INV  | user1@atlassian | useri10105@atlassian.com |   FALSE   |
| JIRAUSER10106 | user2    | INV  | user2@user2     | useri10106@atlassian.com |   FALSE   |
| JIRAUSER10107 | user3    | INV  | user3@atl       | useri10107@atlassian.com |   FALSE   |

What the columns mean:
 * UserKey: User key.
 * UserName: Username, the primary identifier in Server and Data Center.
 * Type: Problem with the email address, either invalid or duplicated, depending on the file.
 * OldEmail: Current email address.
 * NewEmail (editable): Pre-generated email address that unblocks the migration.
 * Tombstone (editable): Controls whether a user should be migrated as Former user
   and deactivated in Cloud. The values are True or False.
   
** How to edit the CSV file **
The values you can change in the CSV files are 'NewEmail' and 'Tombstone':

 * NewEmail *
 The pre-generated email addresses are always valid, so they meet the requirements and let you
 migrate. Note that these emails aren’t actually working and your users won’t be able to log in
 with them. Such emails let you migrate your users, preserving both their activity and identity,
 but not the access. If you’d like some of them to keep access, you can change the value to
 an address your users have access to. However, in the case of active users, we recommend that
 you update their emails directly in the source (e.g. Jira user directory, external directory).
 Note: If you use an email address that already exists in Cloud or is shared by other users
 in this file, the users will be merged. You can use this option to merge some duplicates.
 
 For more info on granting product access, see: 
 https://support.atlassian.com/user-management/docs/update-product-access-settings/

 * Tombstone * 
 Change the value to 'true' if you'd like to migrate specific users as Former user. Such users
 have their activity preserved, but not the identity. Every interaction they ever made will
 be displayed under the name 'Former user'. Former users don't count towards your license
 and can't be restored as active users. If set to 'true', the 'NewEmail' is not used.

** Some recommendations **
Here are all the options you can do with this file:
 * For users that should exist in Cloud, but don’t need access: use default values.
 * For users that should exist in Cloud and need access: set ‘NewEmail’ to a working email.
 * For users that should be merged together: set ‘NewEmail’ to the same address for all of them.
 * For users that should be deactivated: set ‘Tombstone’ to ‘true’.
