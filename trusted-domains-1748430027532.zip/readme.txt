Update trusted domains based on the CSV file

When migrating your users from Server or Data Center to Cloud, you need to decide which
email domains you trust. You can only migrate users from trusted domains. That's usually
done in the migration assistant, but you can use the CSV file as a quicker way to view
all your domains and decide what to do with them.

You can view this and other documentation pages at:
https://support.atlassian.com/migration/docs/review-users-to-trust-email-domains/


** About the CSV file **
You can change existing decisions for each domain, but you can't add or delete domains.
If the number of domains in the uploaded CSV file is different than in the original file,
you won't be able to upload it.

Example CSV file:
+-------------------+------------------+
|    Domain         |     Decision     |
+-------------------+------------------+
| google.com        | NO_DECISION_MADE |
| microsoft.com     | NO_DECISION_MADE |
| untrustworthy.com | NOT_TRUSTED      |
| malicious.org     | NOT_TRUSTED      |
| atlassian.com     | TRUSTED          |
| atlassian.com.au  | TRUSTED          |
+-------------------+------------------+

The value must be: NO_DECISION_MADE, NOT_TRUSTED, or TRUSTED.
Edit the CSV file and upload it back.

** About untrusted domains **
Unless you mark all domains as trusted, you won't be able to migrate. If there are domains
you don't trust, you should delete users from these domains or change their email addresses
to other domains so they don't appear in the list.

You can learn more about this and other solutions in the documentation linked above.
